import os
import hashlib
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

def decrypt_file(file_path, key):
    # Calculer la clé de déchiffrement à partir de la clé de l'utilisateur
    key = hashlib.sha256(key.encode()).digest()

    # Charger les données chiffrées du fichier
    with open(file_path, 'rb') as file:
        data = file.read()

    # Initialiser le déchiffrement
    cipher = Cipher(algorithms.AES(key), modes.CBC(b'\0' * 16), backend=default_backend())
    decryptor = cipher.decryptor()

    # Déchiffrer les données
    pt = decryptor.update(data) + decryptor.finalize()

    # Enlever le padding PKCS7
    unpadder = padding.PKCS7(128).unpadder()
    data = unpadder.update(pt) + unpadder.finalize()
    # Écrire les données déchiffrées dans un nouveau fichier
    os.remove(file_path)
    new_file_path = file_path.replace(".encrypted", "")
    with open(new_file_path, 'wb') as file:
        file.write(data)

def decrypt_directory(directory):
    key = input("Entrez la clé de déchiffrement: ")
    for file_name in os.listdir(directory):
        if os.path.isfile(os.path.join(directory, file_name)) and file_name.endswith(".encrypted") and file_name not in ["decrypt.py"]:
            decrypt_file(os.path.join(directory, file_name), key)

current_directory = os.getcwd()
decrypt_directory(current_directory)
print("Les fichiers ont été déchiffrés avec succès")