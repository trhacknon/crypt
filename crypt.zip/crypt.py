import os
import hashlib
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

def encrypt_file(file_path, key):
    if os.path.basename(file_path) in ["crypt.py", "decrypt.py"]:
        return
    # Calculer la clé de chiffrement à partir de la clé de l'utilisateur
    key = hashlib.sha256(key.encode()).digest()

    # Charger les données du fichier
    with open(file_path, 'rb') as file:
        data = file.read()

    # Initialiser le chiffrement
    cipher = Cipher(algorithms.AES(key), modes.CBC(b'\0' * 16), backend=default_backend())
    encryptor = cipher.encryptor()

    # Ajouter le padding PKCS7
    padder = padding.PKCS7(128).padder()
    data = padder.update(data) + padder.finalize()

    # Chiffrer les données
    ct = encryptor.update(data) + encryptor.finalize()

    # Écrire les données chiffrées dans un nouveau fichier
    os.remove(file_path)
    new_file_path = file_path + ".encrypted"
    with open(new_file_path, 'wb') as file:
        file.write(ct)

def encrypt_directory(directory):
    key = input("Entrez la clé de chiffrement: ")
    for file_name in os.listdir(directory):
        if os.path.isfile(os.path.join(directory, file_name)):
            encrypt_file(os.path.join(directory, file_name), key)

current_directory = os.getcwd()
encrypt_directory(current_directory)
print("Les fichiers ont été chiffrés avec succès")
